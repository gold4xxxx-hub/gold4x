module.exports=[46636,(a,b,c)=>{}];

//# sourceMappingURL=Frontal-gold4x_gold4x__next-internal_server_app__not-found_page_actions_0~zqk19.js.map