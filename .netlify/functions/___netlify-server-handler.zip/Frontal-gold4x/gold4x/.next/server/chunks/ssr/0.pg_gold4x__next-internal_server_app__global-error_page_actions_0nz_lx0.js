module.exports=[15597,(a,b,c)=>{}];

//# sourceMappingURL=0.pg_gold4x__next-internal_server_app__global-error_page_actions_0nz_lx0.js.map