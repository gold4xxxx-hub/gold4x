module.exports=[93899,(a,b,c)=>{}];

//# sourceMappingURL=Frontal-gold4x_gold4x__next-internal_server_app_kyc_admin_page_actions_10l1xpa.js.map