module.exports=[36291,(a,b,c)=>{}];

//# sourceMappingURL=Frontal-gold4x_gold4x__next-internal_server_app_page_actions_0qc-u~x.js.map