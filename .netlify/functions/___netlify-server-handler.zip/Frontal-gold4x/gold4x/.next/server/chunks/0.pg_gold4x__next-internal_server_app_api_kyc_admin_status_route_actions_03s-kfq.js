module.exports=[16047,(e,o,d)=>{}];

//# sourceMappingURL=0.pg_gold4x__next-internal_server_app_api_kyc_admin_status_route_actions_03s-kfq.js.map