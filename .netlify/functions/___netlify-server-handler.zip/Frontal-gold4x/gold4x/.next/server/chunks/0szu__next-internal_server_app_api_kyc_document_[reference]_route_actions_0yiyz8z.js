module.exports=[80232,(e,o,d)=>{}];

//# sourceMappingURL=0szu__next-internal_server_app_api_kyc_document_%5Breference%5D_route_actions_0yiyz8z.js.map