module.exports=[9112,(a,b,c)=>{}];

//# sourceMappingURL=Frontal-gold4x_gold4x__next-internal_server_app_p2p_page_actions_12txhoe.js.map