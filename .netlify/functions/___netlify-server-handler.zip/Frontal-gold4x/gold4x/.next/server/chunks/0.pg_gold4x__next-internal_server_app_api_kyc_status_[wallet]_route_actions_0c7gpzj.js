module.exports=[57316,(e,o,d)=>{}];

//# sourceMappingURL=0.pg_gold4x__next-internal_server_app_api_kyc_status_%5Bwallet%5D_route_actions_0c7gpzj.js.map