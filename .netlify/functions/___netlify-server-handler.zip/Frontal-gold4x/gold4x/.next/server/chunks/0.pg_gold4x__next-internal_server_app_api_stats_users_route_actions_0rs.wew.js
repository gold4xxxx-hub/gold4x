module.exports=[46688,(e,o,d)=>{}];

//# sourceMappingURL=0.pg_gold4x__next-internal_server_app_api_stats_users_route_actions_0rs.wew.js.map