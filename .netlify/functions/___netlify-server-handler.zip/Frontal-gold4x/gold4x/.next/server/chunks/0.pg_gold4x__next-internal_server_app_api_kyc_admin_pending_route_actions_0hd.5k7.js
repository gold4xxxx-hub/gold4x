module.exports=[83997,(e,o,d)=>{}];

//# sourceMappingURL=0.pg_gold4x__next-internal_server_app_api_kyc_admin_pending_route_actions_0hd.5k7.js.map