module.exports=[44847,(a,b,c)=>{}];

//# sourceMappingURL=Frontal-gold4x_gold4x__next-internal_server_app_kyc_page_actions_05z13hz.js.map