module.exports=[56603,(a,b,c)=>{}];

//# sourceMappingURL=Frontal-gold4x_gold4x__next-internal_server_app_docs_page_actions_0a5_ist.js.map