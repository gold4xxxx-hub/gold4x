module.exports=[13050,(e,o,d)=>{}];

//# sourceMappingURL=0.pg_gold4x__next-internal_server_app_api_kyc_submit_route_actions_0pnwcru.js.map