globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/sbqccHxqD5oDqB4VBIcgD/_buildManifest.js",
    "static/sbqccHxqD5oDqB4VBIcgD/_ssgManifest.js",
    "static/sbqccHxqD5oDqB4VBIcgD/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/06jzqa7_wf2qc.js",
    "static/chunks/0cabhydk1ugty.js",
    "static/chunks/03kuv8zxtzcj9.js",
    "static/chunks/turbopack-0jqd5e9gl59so.js"
  ]
};
