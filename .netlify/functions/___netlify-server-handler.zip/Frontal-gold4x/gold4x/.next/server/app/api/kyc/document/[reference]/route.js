var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/kyc/document/[reference]/route.js")
R.c("server/chunks/[root-of-the-server]__0ari54h._.js")
R.c("server/chunks/[root-of-the-server]__0dwpcfa._.js")
R.c("server/chunks/0szu__next-internal_server_app_api_kyc_document_[reference]_route_actions_0yiyz8z.js")
R.m(13381)
module.exports=R.m(13381).exports
