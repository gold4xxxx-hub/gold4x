var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/stats/users/route.js")
R.c("server/chunks/[root-of-the-server]__08nlh_w._.js")
R.c("server/chunks/0ro8_0.u2cdd._.js")
R.c("server/chunks/[root-of-the-server]__0dwpcfa._.js")
R.c("server/chunks/0.pg_gold4x__next-internal_server_app_api_stats_users_route_actions_0rs.wew.js")
R.m(64488)
module.exports=R.m(64488).exports
