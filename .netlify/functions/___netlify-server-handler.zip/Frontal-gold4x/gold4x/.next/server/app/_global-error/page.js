var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__0q_w6s6._.js")
R.c("server/chunks/ssr/0ro8_next_dist_esm_build_templates_app-page_0o94xo9.js")
R.c("server/chunks/ssr/[root-of-the-server]__01d4fii._.js")
R.c("server/chunks/ssr/0ro8_next_dist_00j_h0_._.js")
R.c("server/chunks/ssr/0ro8_next_dist_client_components_builtin_global-error_0v6f1id.js")
R.c("server/chunks/ssr/0.pg_gold4x__next-internal_server_app__global-error_page_actions_0nz_lx0.js")
R.m(72115)
module.exports=R.m(72115).exports
