var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/kyc/submit/route.js")
R.c("server/chunks/[root-of-the-server]__0dkfuws._.js")
R.c("server/chunks/0ro8_0.u2cdd._.js")
R.c("server/chunks/[root-of-the-server]__0dwpcfa._.js")
R.c("server/chunks/0.pg_gold4x__next-internal_server_app_api_kyc_submit_route_actions_0pnwcru.js")
R.m(53761)
module.exports=R.m(53761).exports
