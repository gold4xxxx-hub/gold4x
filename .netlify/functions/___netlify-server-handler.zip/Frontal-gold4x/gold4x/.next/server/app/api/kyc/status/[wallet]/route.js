var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/kyc/status/[wallet]/route.js")
R.c("server/chunks/[root-of-the-server]__0de-82r._.js")
R.c("server/chunks/0ro8_0.u2cdd._.js")
R.c("server/chunks/[root-of-the-server]__0dwpcfa._.js")
R.c("server/chunks/0.pg_gold4x__next-internal_server_app_api_kyc_status_[wallet]_route_actions_0c7gpzj.js")
R.m(99742)
module.exports=R.m(99742).exports
