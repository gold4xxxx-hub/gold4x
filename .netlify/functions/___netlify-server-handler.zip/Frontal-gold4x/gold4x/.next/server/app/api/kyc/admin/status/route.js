var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/kyc/admin/status/route.js")
R.c("server/chunks/[root-of-the-server]__0-ohgxu._.js")
R.c("server/chunks/[root-of-the-server]__0dwpcfa._.js")
R.c("server/chunks/0.pg_gold4x__next-internal_server_app_api_kyc_admin_status_route_actions_03s-kfq.js")
R.m(67676)
module.exports=R.m(67676).exports
