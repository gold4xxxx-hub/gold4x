var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/kyc/admin/pending/route.js")
R.c("server/chunks/[root-of-the-server]__136c_.e._.js")
R.c("server/chunks/[root-of-the-server]__0dwpcfa._.js")
R.c("server/chunks/0.pg_gold4x__next-internal_server_app_api_kyc_admin_pending_route_actions_0hd.5k7.js")
R.m(98030)
module.exports=R.m(98030).exports
